Pass a single csv file as a command line argument to main.py

E.g. python main.py Pressure_data.csv

main.py reads every column in the csv file as a separate time series. For every time series, it performs
hyperparameter tuning for variance fraction & minimum window length and saves the elbow curves to the following two files.
ElbowCurve_{Variable-name}_Number_of_intervals_vs_Min_window_length.csv
ElbowCurve_{Variable-name}_Number_of_intervals_vs_Variance_fraction.csv

Using the optimal hyperparameters, main.py calls the Interval_Halving algorithm again and saves the plot to
IntervalHalving_{Variable-name}.csv

Pressure_data.csv has three columns/variables (PSPCKL, PSPCKR, PSPCKOU), so so two separate csv files (ElbowCurve and
IntervalHalving) are created for each of the three variables.

Convention for plots saved as csv file:
Column 1- variable along x-axis
Column 2- variable along y-axis
Column 3 ("Colors") - Color specified according to matplotlib format
(e.g. 'b' - blue, 'r' - red, 'k' - black)
Column 4 ("Point_sizes") - According to matplotlib format

Test plot.ipynb gives an example for generating the plots from the csv files using matplotlib.