import sys
import numpy as np
import pandas as pd
from Interval_Halving import Modified_Interval_Halving
from optimal_hyperparameter import AMethod

# Reading data from csv file
try:
    df_data = pd.read_csv(sys.argv[1]) # Each column is considered as a separate time series
except:
    sys.exit('Invalid file passed as argument')
    
for colname in list(df_data.columns):
    tseries = df_data[colname].dropna().to_numpy()
    err_series = np.var(tseries)
    # Hyperparameter tuning for variance fraction
    var_fracs = np.linspace(0.01, 0.1, 20)
    count_intervals_var = np.zeros(20,)
    for frac_ind, frac in enumerate(var_fracs):
        model = Modified_Interval_Halving(noise_err = frac*err_series, min_window_len = 1, \
                                          title = colname, suppress_print = True)
        count_intervals_var[frac_ind] = model.train_model(tseries)
        
    elbow_model_var = AMethod()
    elbow_idx_var = elbow_model_var.get_elbow_point(var_fracs, count_intervals_var)
    elbow_model_var.write_to_csv(colname, 'Variance_fraction', 'Number_of_intervals')
    opt_var_fraction = var_fracs[elbow_idx_var]
    
    # Hyperparameter tuning for minimum window length
    window_lens = np.arange(100, 1001, 100)
    count_intervals_window = np.zeros(10,)    
    for ind_window, window_len in enumerate(window_lens):
        model = Modified_Interval_Halving(noise_err = 0.01*err_series, min_window_len = window_len, \
                                          title = colname, suppress_print = True)
        count_intervals_window[ind_window] = model.train_model(tseries)  
        
    elbow_model_window = AMethod()
    elbow_idx_window = elbow_model_window.get_elbow_point(window_lens, count_intervals_window)
    elbow_model_window.write_to_csv(colname, 'Min_window_length', 'Number_of_intervals')
    opt_window = count_intervals_window[elbow_idx_window]    

    # Running interval halving
    final_model = Modified_Interval_Halving(noise_err = opt_var_fraction*err_series, min_window_len = opt_window, \
                                            ylabel = colname, suppress_print = True)
    final_model.train_model(tseries)
    final_model.write_to_csv(colname)

if __name__ == 'main':
    main()    
    

    