from AR_Model import AR_Approach
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import copy
from sklearn import linear_model
from IPython.display import clear_output
from sklearn.cluster import KMeans
from kneed import KneeLocator # kneed needs to be installed from the shell

def AR_plots(Input_Data, Bench_Mod):
    # Default parameters for AR model
    Ar_Order = 3    
    Mm_Fra = 0.1
    Peak_Fra = 0.05
    fill_outlier = False
    UpDown_Mode = False    
    
    # Computing the AR coefficients
    Calc_Models = []        
    for case_n in range(Input_Data.shape[1]):
        AR = AR_Approach(Ar_Order, Mm_Fra, Peak_Fra, fill_outlier, UpDown_Mode)
        AR.Get_Model(Input_Data.iloc[:,case_n])
        Calc_Models.append(np.array(AR.Mod))

    Calc_Models = np.array(Calc_Models)
    
    plots_to_return = []
    if Bench_Mod is not None: # Bar plot of angles with benchmark model
        Bench_Angles = np.zeros((Input_Data.shape[1],), dtype = float)
        for i in range(Input_Data.shape[1]):
            Bench_Angles[i] = np.rad2deg(np.arccos((Calc_Models[i,:] @ Bench_Mod)/
                                         (np.linalg.norm(Calc_Models[i,:])*np.linalg.norm(Bench_Mod))))
        
        fig = plt.figure()
        ax = fig.add_axes([0,0,1,1])
        ax.bar(list(Input_Data.columns), Bench_Angles)
        plt.xlabel('Case ID')
        plt.ylabel('Angle (degrees)')
        plots_to_return.append(('Angles with Benchmark Model', fig))
        
    else: 
        # Bar plot of angles with average model
        Avg_Mod = np.mean(Calc_Models, axis = 0)
        Avg_Angles = np.zeros((Input_Data.shape[1],), dtype = float)
        for i in range(Input_Data.shape[1]):
            Avg_Angles[i] = np.rad2deg(np.arccos((Calc_Models[i,:] @ Avg_Mod)/
                                         (np.linalg.norm(Calc_Models[i,:])*np.linalg.norm(Avg_Mod))))
            
        fig = plt.figure()
        fig.add_axes([0,0,1,1])
        plt.bar(list(Input_Data.columns), Avg_Angles)
        plt.xlabel('Case ID')
        plt.ylabel('Angle (degrees)')
        plots_to_return.append(('Angles with Average Model', fig))
        
        # Pairwise heatmap of computed models
        Model_Angles = np.zeros((Input_Data.shape[1], Input_Data.shape[1]), dtype = float)
        for i in range(Input_Data.shape[1]):
            for j in range(i+1, Input_Data.shape[1]):
                angle_calc = np.rad2deg(np.arccos((Calc_Models[i,:] @ Calc_Models[j,:])/
                                                  (np.linalg.norm(Calc_Models[i,:])*np.linalg.norm(Calc_Models[j,:]))))
                Model_Angles[i, j] = angle_calc
                Model_Angles[j, i] = angle_calc
        
        sns.set(font_scale=1.3)
        plt.figure()
        ax = sns.heatmap(np.around(Model_Angles, decimals = 2), cmap = "OrRd", robust=True, annot=True, 
                         xticklabels = list(Input_Data.columns), yticklabels = list(Input_Data.columns))
        plots_to_return.append(('Pairwise Heatmap', ax.get_figure()))
        
    return plots_to_return
        
    