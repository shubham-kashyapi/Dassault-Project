import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import copy
from sklearn import linear_model
from IPython.display import clear_output
from sklearn.cluster import KMeans
from kneed import KneeLocator # kneed needs to be installed from the shell

class AR_Approach():
    def __init__(self, Ar_Order=3, Mm_Fra=0.1, Peak_Fra=0.05, fill_outlier=False, UpDown_Mode=True):
        self.Ar_Order=Ar_Order
        #self.X=pd.DataFrame()
        [self.X,self.UpX,self.DnX,self.Y,self.UpY,self.DnY]=[pd.DataFrame() for i in range(6)]
        self.peaks = []
        self.valleys = [0] # First point of series is considered as valley
        self.New_Order=[0]
        self.Mm_Fra=Mm_Fra
        self.Peak_Fra=Peak_Fra
        self.fill_outlier=fill_outlier
        self.UpDown_Mode=UpDown_Mode
        [self.regr, self.regr_Up, self.regr_Dn] = [linear_model.LinearRegression() for i in range(3)]
    #%% Data set function
    def Data_set(self, Ser):
        '''
        Creates datasets X and Y for linear regression
        '''
        self.X.loc[:,0] = Ser.loc[self.Ar_Order-1:0:-1]
        self.X.index=[i for i in range(self.Ar_Order)]
        self.Y.loc[:,0] = Ser.loc[self.Ar_Order:len(Ser)]
        self.Y.index=[i for i in range(len(self.Y))]
        for Order in range(self.Ar_Order+1,len(Ser)):
            self.X.loc[:,Order-self.Ar_Order] = Ser.values[Order-1:Order-self.Ar_Order-1:-1]
        
    #%% Preprocessor function
    def Pre_Processor(self, Ser):
        '''
        Works like MATLAB filloutlier function. Drops missing values
        Issue to resolve: Rolling std generates NaN value for the first index, filloutlier performs differently\
            may be due to difference incalculating std, instead of dropping the function should work like \
                MATLAB fillmissing function.
        '''
        Ser.dropna(inplace=True) # Droping missing values
        if self.fill_outlier==True: # To remove outliers
            Mm_Order=round(len(Ser)*self.Mm_Fra)
            Ser_rollmean=Ser.rolling(Mm_Order+1,min_periods=0).mean()
            Ser_rollstd= Ser.rolling(Mm_Order+1,min_periods=0).std()
            for i in range(len(Ser)):
                if Ser.loc[i]>Ser_rollmean.loc[i]+3*Ser_rollstd.loc[i] \
                    or Ser.loc[i]<Ser_rollmean.loc[i]-3*Ser_rollstd.loc[i]:
                    Ser.loc[i]=np.nan
            Ser.interpolate('nearest', inplace = True)
            
        #%% Up-Down Reorder analysis
    def Up_Down_Reorder(self, altitude_of_interest):
        '''
        Identifies peaks and valleys from altitude data.
        Reorders the data to form separate dataframes for up and down analyses.
        '''
        Peak_Window=round(len(altitude_of_interest)*self.Peak_Fra)
        # peaks = []
        # valleys = [1] # First point of series is considered as valley
        for i in range(Peak_Window,len(altitude_of_interest)-Peak_Window-1):
            if altitude_of_interest.loc[i-Peak_Window:i-1].max() < altitude_of_interest.loc[i] \
            and altitude_of_interest.loc[i+1:i+Peak_Window].max() < altitude_of_interest.loc[i]:
                self.peaks.append(i)
            elif altitude_of_interest.loc[i-Peak_Window:i-1].min() > altitude_of_interest.loc[i] \
            and altitude_of_interest.loc[i+1:i+Peak_Window].min() > altitude_of_interest.loc[i]:
                self.valleys.append(i)
    
        self.valleys.append(len(altitude_of_interest)-1)
        

        for v in range(1,len(self.valleys)):
            peakin=[]
            for p in range(len(self.peaks)):
                if self.valleys[v-1]<self.peaks[p] and self.peaks[p]<self.valleys[v]:
                    peakin.append(self.peaks[p])
            if len(peakin)!=0:
                self.New_Order.append(peakin[0])
                self.New_Order.append(self.valleys[v])
            elif v==len(self.valleys)-1:
                self.New_Order.pop() # The last element is already a valley. Seccondlast valley needs to be removed
                self.New_Order.append(self.valleys[v])
        
        New_Order_Re = copy.deepcopy(self.New_Order)
        
        self.UpX=pd.DataFrame(self.X.iloc[:, 0:New_Order_Re[1]-self.Ar_Order+1])
        self.UpY = pd.DataFrame(self.Y.T.iloc[0,0:New_Order_Re[1]-self.Ar_Order+1])
        New_Order_Re.pop(0)    
        self.DnX = pd.DataFrame()
        self.DnY = pd.DataFrame()
        while len(New_Order_Re)>1:
            if len(New_Order_Re)%2==1:
                self.UpX=pd.concat([self.UpX,self.X.iloc[:,New_Order_Re[0]+1-self.Ar_Order:New_Order_Re[1]-self.Ar_Order+1]],axis=1)
                self.UpY=pd.concat([self.UpY,self.Y.T.iloc[0,New_Order_Re[0]+1-self.Ar_Order:New_Order_Re[1]-self.Ar_Order+1]])
            else:
                self.DnX=pd.concat([self.DnX,self.X.iloc[:,New_Order_Re[0]+1-self.Ar_Order:New_Order_Re[1]-self.Ar_Order+1]],axis=1)
                self.DnY=pd.concat([self.DnY,self.Y.T.iloc[0,New_Order_Re[0]+1-self.Ar_Order:New_Order_Re[1]-self.Ar_Order+1]])
            New_Order_Re.pop(0)
           
           #%% Method for recronstructing predicted Y from Up Down analysis and calculating rsquare
    def Reconstruct_UD(self):
        idup = 0
        iddn = 0
        New_Order_Re=copy.deepcopy(self.New_Order)
        self.Ypr_Up=pd.DataFrame(self.Ypr_Up)
        self.Ypr_Dn=pd.DataFrame(self.Ypr_Dn)
        self.reY = pd.DataFrame(self.Ypr_Up.iloc[idup:New_Order_Re[1]-self.Ar_Order+1])
        idup = idup + New_Order_Re[1]-self.Ar_Order+1
        New_Order_Re.pop(0)
        while len(New_Order_Re)>1:
            if len(New_Order_Re)%2==1:
                self.reY = pd.concat([self.reY,self.Ypr_Up.iloc[idup:idup+New_Order_Re[1]\
                                                                -New_Order_Re[0]]],ignore_index=True)
                idup = idup+New_Order_Re[1]-New_Order_Re[0]
            else:
                self.reY = pd.concat([self.reY, self.Ypr_Dn.iloc[iddn:iddn+New_Order_Re[1]\
                                                                 -New_Order_Re[0]]],ignore_index=True)
                iddn = iddn+New_Order_Re[1]-New_Order_Re[0]
            New_Order_Re.pop(0)
        Er_ud=((self.reY-self.Y)**2).sum() # Squared sum of residual error  
        self.rmse_UD=(Er_ud/len(self.Y))**0.5
        self.rsqr_UD=1-Er_ud/((len(self.Y)-1)*self.Y.var()) # r score for Up-down dynamics           
        
            #%% Creating Model
    def Get_Model(self, Ser, altitude_of_interest=None):
        '''
        Yields coefficints from linear regression from given data sets for given AR order.
        '''
        self.Pre_Processor(Ser)
        self.Data_set(Ser)
        self.regr.fit(self.X.T,self.Y)
        Coef=self.regr.coef_.tolist()
        Inter_Coef=self.regr.intercept_.tolist()
        Inter_Coef.extend(*Coef)
        self.Mod=Inter_Coef # Model
        self.Ypr = self.regr.predict(self.X.T) # Predictions
        self.rsqr=self.regr.score(self.X.T,self.Y)
        
        if self.UpDown_Mode == True:
            self.Up_Down_Reorder(altitude_of_interest)
            self.regr_Up.fit(self.UpX.T, self.UpY)
            self.regr_Dn.fit(self.DnX.T, self.DnY)
            Coef_Up=self.regr_Up.coef_.tolist()
            Inter_Coef_Up=self.regr_Up.intercept_.tolist()
            Inter_Coef_Up.extend(*Coef_Up)
            self.Mod_Up=Inter_Coef_Up
            Coef_Dn=self.regr_Dn.coef_.tolist()
            Inter_Coef_Dn=self.regr_Dn.intercept_.tolist()
            Inter_Coef_Dn.extend(*Coef_Dn)
            self.Mod_Dn=Inter_Coef_Dn            
            self.Ypr_Up = self.regr_Up.predict(self.UpX.T)
            self.Ypr_Dn = self.regr_Dn.predict(self.DnX.T)
            self.Reconstruct_UD()