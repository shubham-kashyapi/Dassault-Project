import sys
import numpy as np
import pandas as pd
from Interval_Halving import Modified_Interval_Halving
from optimal_hyperparameter import AMethod
import time


def Interval_Halving_plots(df_data): # Pandas dataframe where each column corresponds to a different time series
    plots_to_return = []
    
    for colname in list(df_data.columns):

                tseries = df_data[colname].dropna().to_numpy()
                err_series = np.var(tseries)
                # Hyperparameter tuning for variance fraction
                var_fracs = np.linspace(0.01, 0.1, 20)
                count_intervals = np.zeros(20, )
                for frac_ind, frac in enumerate(var_fracs):
                    time.sleep(0.1)
                    model = Modified_Interval_Halving(noise_err=frac * err_series, min_window_len=100, \
                                                      title=colname, suppress_print=True)
                    count_intervals[frac_ind] = model.train_model(tseries)

                elbow_model_var = AMethod()
                elbow_idx_var = elbow_model_var.get_elbow_point(var_fracs, count_intervals)
                opt_var_fraction = var_fracs[elbow_idx_var]
                plot_name_var = 'ElbowCurve_{}_Number_of_intervals_vs_Variance_fraction'.format(colname)
                plot_obj_var = elbow_model_var.plot_elbow_curve(colname, 'Variance_fraction', 'Number_of_intervals')                
                plots_to_return.append((plot_name_var, plot_obj_var))
                
                # Hyperparameter tuning for minimum window length
                window_lens = np.arange(100, 1001, 100)
                count_intervals_window = np.zeros(10,)    
                for ind_window, window_len in enumerate(window_lens):
                    time.sleep(0.1)
                    model = Modified_Interval_Halving(noise_err = 0.01*err_series, min_window_len = window_len, \
                                                      title = colname, suppress_print = True)
                    count_intervals_window[ind_window] = model.train_model(tseries)  

                elbow_model_window = AMethod()
                elbow_idx_window = elbow_model_window.get_elbow_point(window_lens, count_intervals_window)
                opt_window = count_intervals_window[elbow_idx_window]
                plot_name_window = 'ElbowCurve_{}_Number_of_intervals_vs_Min_window_length'.format(colname)
                plot_obj_window = elbow_model_window.plot_elbow_curve(colname, 'Variance_fraction', 'Min_window_length')                
                plots_to_return.append((plot_name_window, plot_obj_window))
                
                # Running interval halving
                final_model = Modified_Interval_Halving(noise_err = opt_var_fraction*err_series, min_window_len = opt_window, \
                                                        ylabel=colname, suppress_print=True)
                final_model.train_model(tseries)
                plot_name_interval = 'IntervalHalving_{}'.format(colname)
                plot_obj_interval = final_model.plot_data_intervals()                
                plots_to_return.append((plot_name_interval, plot_obj_interval))
                
    return plots_to_return
      
    

    