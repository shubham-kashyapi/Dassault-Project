import streamlit as st
import numpy as np
import pandas as pd
from Interval_Halving_helper import Interval_Halving_plots
from AR_helper import AR_plots
from MVI_helper import MVI_plots
import time

def print_hi(name):
    # Use a breakpoint in the code line below to debug your script.
    print(f'Hi, {name}')  # Press ⌘F8 to toggle the breakpoint.


# Press the green button in the gutter to run the script.
if __name__ == '__main__':

    print_hi('Loading streamline UI')
    st.title('Anamoly Detection from Time Series')
    
    option = st.selectbox('Select the Model', ('Interval Halving', 'Auto Regression', 'Minimum Variance Index'))
    processing_option, benchmark_file, benchmark_mod, data_file = None, None, None, None
    
    # If chosen algorithm is AR, choose the processing mode and upload the benchmark model (if required)
    if option == 'Auto Regression':
        st.title('Processing Options')
        processing_option = st.selectbox("Select whether or not to compare with a benchmark model.", ('No Benchmark', 'Benchmark'))
        if processing_option == 'Benchmark':
            benchmark_file = st.file_uploader("\n\nSelect a file(csv) containing the benchmark model.")
            if benchmark_file is not None:
                benchmark_mod = np.array(pd.read_csv(benchmark_file).iloc[0, 1:], dtype = float)

    data_file = st.file_uploader("Select a single file(csv) containing the Time Series Data")
    if data_file is not None:
        st.header('Input')
        st.write(data_file.name)
        df_data = pd.read_csv(data_file)
        df_data.dropna()
        st.line_chart(df_data)
        if st.checkbox('Show Input Data'):
            st.write(df_data)

        if option == "Interval Halving":            
            plots_to_show = Interval_Halving_plots(df_data)
            for (header_name, plot_display) in plots_to_show:
                st.header(header_name)
                st.pyplot(plot_display)

        elif option == "Auto Regression":
            plots_to_show = AR_plots(df_data, benchmark_mod)
            for (header_name, plot_display) in plots_to_show:
                st.header(header_name)
                st.pyplot(plot_display)
                
        elif option == "Minimum Variance Index":
            plots_to_show = MVI_plots(df_data)
            for (header_name, plot_display) in plots_to_show:
                st.header(header_name)
                st.pyplot(plot_display)
            
        