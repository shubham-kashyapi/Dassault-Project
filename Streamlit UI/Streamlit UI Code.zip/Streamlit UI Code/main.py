import streamlit as st
import numpy as np
import pandas as pd
from Interval_Halving_helper import Interval_Halving_plots
from AR_helper import AR_plots
from MVI_helper import MVI_plots
import time

def print_hi(name):
    # Use a breakpoint in the code line below to debug your script.
    print(f'Hi, {name}')  # Press ⌘F8 to toggle the breakpoint.


# Press the green button in the gutter to run the script.
if __name__ == '__main__':

    print_hi('Loading Anomaly Detection UI')
    st.title('Anamoly Detection from Time Series')
    
    option = st.sidebar.selectbox('Select the Model', ('Interval Halving', 'Auto Regression', 'Minimum Variance Index'))
    processing_option, benchmark_data, data_file, AR_Order = None, None, None, None
    
    # If chosen algorithm is AR, choose the AR order, processing mode and upload the benchmark model (if required)
    if option == 'Auto Regression':
        AR_Order = int(st.sidebar.number_input('Specify the order of the AR model (integer between 1 and 10)', 
                       min_value = 1, max_value = 10))
        outlier_removal = False
        if st.sidebar.checkbox('Remove outliers'):
            outlier_removal = True
        processing_option = st.sidebar.selectbox("Select whether or not to compare with a benchmark model.", ('No Benchmark', 'Benchmark'))
        if processing_option == 'Benchmark':
            benchmark_file = st.sidebar.file_uploader("\n\n Select a csv file containing the benchmark (coefficients as a single row or time                                                        series as a single column)")
            if benchmark_file is not None:
                benchmark_data = pd.read_csv(benchmark_file)

    data_file = st.file_uploader("Select a single file(csv) containing the Time Series Data. Each column should contain a header and a time                                   series.")
    if data_file is not None:
        st.header('Input')
        st.write(data_file.name)
        df_data = pd.read_csv(data_file)
        df_data.dropna()
        st.line_chart(df_data)
        if st.checkbox('Show Input Data'):
            st.write(df_data)

        if option == "Interval Halving":            
            plots_to_show = Interval_Halving_plots(df_data)
            for (header_name, plot_display) in plots_to_show:
                st.header(header_name)
                st.pyplot(plot_display)

        elif option == "Auto Regression":
            plots_to_show = AR_plots(df_data, benchmark_data, AR_Order, outlier_removal)
            for (header_name, plot_display) in plots_to_show:
                st.header(header_name)
                st.pyplot(plot_display)
                
        elif option == "Minimum Variance Index":
            plots_to_show = MVI_plots(df_data)
            for (header_name, plot_display) in plots_to_show:
                st.header(header_name)
                st.pyplot(plot_display)
            
        